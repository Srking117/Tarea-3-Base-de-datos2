
from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.models import Usuario, Viaje, Ciudad, Transporte, Atraccion
from datetime import datetime

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/usuarios")
def crear_usuario(nombre: str, email: str, contrasena: str, db: Session = Depends(get_db)):
    usuario = Usuario(nombre=nombre, email=email, contrasena=contrasena)
    db.add(usuario)
    db.commit()
    db.refresh(usuario)
    return {"message": "Usuario creado", "id": usuario.id}

@router.post("/viajes")
def crear_viaje(id_creador: int, nombre: str, descripcion: str, db: Session = Depends(get_db)):
    viaje = Viaje(id_creador=id_creador, nombre=nombre, descripcion=descripcion)
    db.add(viaje)
    db.commit()
    db.refresh(viaje)
    return {"message": "Viaje creado", "id": viaje.id}

@router.post("/viajes/{viaje_id}/ciudades")
def agregar_ciudad(viaje_id: int, nombre: str, fecha_llegada: datetime, descripcion: str, google_maps_url: str, db: Session = Depends(get_db)):
    ciudad = Ciudad(id_viaje=viaje_id, nombre=nombre, fecha_llegada=fecha_llegada, descripcion=descripcion, google_maps_url=google_maps_url)
    db.add(ciudad)
    db.commit()
    db.refresh(ciudad)
    return {"message": "Ciudad agregada al viaje", "id": ciudad.id}

@router.post("/ciudades/{ciudad_id}/atracciones")
def agregar_atraccion(ciudad_id: int, nombre: str, descripcion: str, horario_visita: datetime, duracion: float, google_maps_url: str, db: Session = Depends(get_db)):
    atraccion = Atraccion(id_ciudad=ciudad_id, nombre=nombre, descripcion=descripcion, horario_visita=horario_visita, duracion=duracion, google_maps_url=google_maps_url)
    db.add(atraccion)
    db.commit()
    db.refresh(atraccion)
    return {"message": "Atracción agregada", "id": atraccion.id}

@router.post("/viajes/{viaje_id}/transportes")
def agregar_transporte(viaje_id: int, ciudad_origen: str, ciudad_destino: str, duracion: float, medio: str, precio: float, db: Session = Depends(get_db)):
    transporte = Transporte(id_viaje=viaje_id, ciudad_origen=ciudad_origen, ciudad_destino=ciudad_destino, duracion=duracion, medio=medio, precio=precio)
    db.add(transporte)
    db.commit()
    db.refresh(transporte)
    return {"message": "Transporte agregado al viaje", "id": transporte.id}

@router.get("/viajes/{viaje_id}/itinerario")
def generar_itinerario(viaje_id: int, db: Session = Depends(get_db)):
    viaje = db.query(Viaje).filter(Viaje.id == viaje_id).first()
    if not viaje:
        raise HTTPException(status_code=404, detail="Viaje no encontrado")

    # Obtener las ciudades, atracciones y transportes del viaje
    ciudades = db.query(Ciudad).filter(Ciudad.id_viaje == viaje_id).order_by(Ciudad.fecha_llegada).all()
    transportes = db.query(Transporte).filter(Transporte.id_viaje == viaje_id).all()
    atracciones = db.query(Atraccion).join(Ciudad).filter(Ciudad.id_viaje == viaje_id).order_by(Atraccion.horario_visita).all()

    itinerario = []

    for ciudad in ciudades:
        actividades = [atraccion for atraccion in atracciones if atraccion.id_ciudad == ciudad.id]
        transportes_ciudad = [transporte for transporte in transportes if transporte.ciudad_origen == ciudad.nombre or transporte.ciudad_destino == ciudad.nombre]

        itinerario.append({
            "ciudad": ciudad.nombre,
            "fecha_llegada": ciudad.fecha_llegada,
            "descripcion": ciudad.descripcion,
            "actividades": [{"nombre": atraccion.nombre, "horario": atraccion.horario_visita, "duracion": atraccion.duracion} for atraccion in actividades],
            "transportes": [{"origen": transporte.ciudad_origen, "destino": transporte.ciudad_destino, "duracion": transporte.duracion, "medio": transporte.medio} for transporte in transportes_ciudad]
        })

    return itinerario

