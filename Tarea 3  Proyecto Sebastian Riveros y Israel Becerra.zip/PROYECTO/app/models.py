
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Float
from sqlalchemy.orm import relationship
from app.database import Base

class Usuario(Base):
    __tablename__ = "usuarios"
    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String, nullable=False)
    email = Column(String, unique=True, nullable=False)
    contrasena = Column(String, nullable=False)

    viajes = relationship("Viaje", back_populates="creador")


class Viaje(Base):
    __tablename__ = "viajes"
    id = Column(Integer, primary_key=True, index=True)
    id_creador = Column(Integer, ForeignKey("usuarios.id"), nullable=False)
    nombre = Column(String, nullable=False)
    descripcion = Column(String)
    creador = relationship("Usuario", back_populates="viajes")
    ciudades = relationship("Ciudad", back_populates="viaje")
    transportes = relationship("Transporte", back_populates="viaje")

class Ciudad(Base):
    __tablename__ = "ciudades"
    id = Column(Integer, primary_key=True, index=True)
    id_viaje = Column(Integer, ForeignKey("viajes.id"), nullable=False)
    nombre = Column(String, nullable=False)
    fecha_llegada = Column(DateTime, nullable=False)
    descripcion = Column(String)
    google_maps_url = Column(String)
    
    viaje = relationship("Viaje", back_populates="ciudades")

class Transporte(Base):
    __tablename__ = "transportes"
    id = Column(Integer, primary_key=True, index=True)
    id_viaje = Column(Integer, ForeignKey("viajes.id"), nullable=False)
    ciudad_origen = Column(String, nullable=False)
    ciudad_destino = Column(String, nullable=False)
    duracion = Column(Float, nullable=False)
    medio = Column(String, nullable=False)
    precio = Column(Float, nullable=False)
    viaje = relationship("Viaje", back_populates="transportes")

class Atraccion(Base):
    __tablename__ = "atracciones"
    id = Column(Integer, primary_key=True, index=True)
    id_ciudad = Column(Integer, ForeignKey("ciudades.id"), nullable=False)
    nombre = Column(String, nullable=False)
    descripcion = Column(String)
    horario_visita = Column(DateTime)
    duracion = Column(Float)
    google_maps_url = Column(String)
