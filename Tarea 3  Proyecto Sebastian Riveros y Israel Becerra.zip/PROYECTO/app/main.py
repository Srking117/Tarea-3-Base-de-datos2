
from fastapi import FastAPI
from app.database import Base, engine
from app.routes import router
import uvicorn  # Asegúrate de importar uvicorn

# Crear las tablas de la base de datos
Base.metadata.create_all(bind=engine)

# Crear la instancia de la aplicación FastAPI
app = FastAPI()

# Incluir las rutas
app.include_router(router, prefix="")

# Iniciar el servidor si este archivo es el principal
if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)
